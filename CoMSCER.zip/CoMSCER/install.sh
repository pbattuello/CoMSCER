#/usr/bin/bash

echo -e "Installing genomic references..."


../bin/install_ref.py


echo -e "Installation completed. Enjoy!"

