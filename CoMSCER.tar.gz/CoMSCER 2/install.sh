#/usr/bin/bash

echo -e "Installing GRCh38 reference..."


bin/install_ref.py


echo -e "Installation completed. Enjoy!"

