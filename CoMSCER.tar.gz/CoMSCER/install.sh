#/usr/bin/bash

initial_path=$PWD

a=$(which python); b=$(echo $a | awk '{split($1, a, "bin"); print a[1]}'); path=$(echo $b"lib/python3.11/site-packages/SigProfilerMatrixGenerator/references/chromosomes/tsb"); mkdir -p $path

cd $path

ln -s $initial_path"/GRCh38"

cd $initial_path

